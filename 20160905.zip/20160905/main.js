// require("./src/css/abc.css");
// var abc = require("./src/js/abc.js");
// console.log(abc);
// console.log(abc.add(123,456));
// console.log(abc.minus(456,123));
// 
require("./src/css/abc.css");
require("./src/less.less");