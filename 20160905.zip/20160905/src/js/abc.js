module.exports = {
	add : function(n1,n2){
		return n1+n2;
	},
	minus : function(n1,n2){
		return n1 - n2;
	}
}